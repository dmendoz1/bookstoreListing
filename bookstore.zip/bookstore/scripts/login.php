<?php 

include('credentials.php');
global $connection;

$data = json_decode(file_get_contents("php://input"));
$email = $data->email;
$password = $data->password;

$query = "SELECT ID, email  FROM users WHERE email='$email' AND password= '$password'";

$result = $connection->query($query);
$row = $result->fetch_assoc();
if($row > 0) {
	$token = $email . " | " . uniqid() . uniqid();
	$id = $row['ID'];
	$query2 = "UPDATE users SET token='$token' WHERE email = '$email' AND password='$password'";
	$result2 = $connection->query($query2);
	echo json_encode(array("token"=>$token, "id"=>$id));
} else {
	echo "no user found";
}
?>