<?php 
	include('credentials.php');
	global $connection;
	$data = json_decode(file_get_contents("php://input"));
	$bookName = $data->bookName;
	$author = $data->author;
	$price = $data->price;
	$category = $data->category;
	$bookDescription = $data->description;
	$id = $data->id;

	$query = "UPDATE books SET bookName= '$bookName', author='$author', price='$price', category='$category', bookDescription='$bookDescription' WHERE ID='$id'";
	$result = $connection->query($query);
	if($result) {
		echo "successful";
	} else {
		echo "not successful";
	}
	mysqli_close($connection);
?>