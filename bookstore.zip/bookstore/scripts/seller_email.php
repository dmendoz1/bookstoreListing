<?php
	include('credentials.php');
	global $connection;
	$data = json_decode(file_get_contents("php://input"));
	$sellerId = $data->sellerId;
	$query = "SELECT email, name FROM users WHERE ID='$sellerId'";
	$result = $connection->query($query);
	$data = array();
	while($row = mysqli_fetch_assoc($result)) { 
		$data[] = $row;
	}
	echo json_encode($data);
	mysqli_close($connection);
?>