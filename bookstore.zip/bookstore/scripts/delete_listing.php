<?php 
	include('credentials.php');
	global $connection;
	$data = json_decode(file_get_contents("php://input"));
	$id = $data->id;
	$query = "DELETE FROM books WHERE ID='$id'";
	$result = $connection->query($query);
	if($result) {
		echo  "successful";
	} else {
		echo "not successful";
	}
	mysqli_close($connection);
?>