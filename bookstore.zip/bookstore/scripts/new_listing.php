<?php
	include('credentials.php');
	global $connection;

	$data = json_decode(file_get_contents("php://input"));
	$bookName = $data->name;
	$author = $data->author;
	$category = $data->category;
	$price = $data->price;
	$sellerId = $data->sellerId;
	$description = $data->description;

	$query = 'INSERT INTO books (bookName, author, price, sellerId, category, bookDescription) VALUES ("'.$bookName.'", "'.$author.'", "'.$price.'", "'.$sellerId.'", "'.$category.'", "'.$description.'")';
	$result = $connection->query($query);
	if($result) {
		echo "successful";
	} else {
		echo "could not add listing";
	}

?>