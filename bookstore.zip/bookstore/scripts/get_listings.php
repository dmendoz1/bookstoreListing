<?php
	include('credentials.php');
	global $connection;
	$query = 'SELECT * FROM books ORDER BY id DESC';
	$result = $connection->query($query);
	$data = array();
	while($row = mysqli_fetch_assoc($result)) { 
		$data[] = $row;
	}
	echo json_encode($data);
	mysqli_close($connection);
?>