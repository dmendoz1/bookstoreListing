<?php
	include('credentials.php');
	global $connection;

	$data = json_decode(file_get_contents("php://input"));
	$token = $data->token;
	$query = "UPDATE users SET token='LOGGED OUT' WHERE token=".$token."";
	$result = $connection->query($query);
	if($result){ 
		echo 'logged out';
	} else {
		echo 'not logged out';
	}
?>