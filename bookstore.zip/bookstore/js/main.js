
/* LOGIN */
function login(e){
	e.preventDefault();
	var email = $('#email').val();
	var password = $('#password').val()
	if (email.length == 0 || password.length == 0) {
		$("#login-status").html('please fill out both fields');
		return false;
	}
	var data = {
		email: $('#email').val(),
		password: $('#password').val()
	}

	$.post("scripts/login.php", JSON.stringify(data), function(result){
        if(result == "no user found") {
			$("#login-status").html('Incorrect email or password. Please try again');
		} else {
			var data = JSON.parse(result);
			localStorage.setItem("token", JSON.stringify(data.token));
			localStorage.setItem("userId", data.id);
			window.location.replace("homepage.html");
		}
    });
}


/* LOGOUT */
function logout(e){
	e.preventDefault();
	var data = {
		token : localStorage.getItem("token"),
	}
	$.post("scripts/logout.php", JSON.stringify(data), function(result){
        if(result == "logged out") {
        	localStorage.clear();
			window.location.replace("index.html");
		} else {
			alert('not logged out');
		}
    });
}

$(document).ready(function() {

	/* DISABLE LOGIN BUTTON WHEN FIELDS HAVEN'T BEEN FILLED */
	$('#login-form input').change(function() {
		if($('#email').val().length > 0 && $('#password').val().length > 0 ) {
			$('#login-btn').removeClass('disabled');
			$('#login-btn').prop("disabled", false)
		} else {
			$('#login-btn').prop("disabled", true);
			if(!$('#login-btn').hasClass('disabled')) {
				$('#login-btn').addClass('disabled');
			}
		}
	})

	//login
	$('#login-btn').click(login);
	$('#logout').click(logout);
});

$(window).on('load', function() {
	/* REDIRECT TO MAIN PAGE IF NOT AN ADMIN */
	var pathname = window.location.pathname;
	if((pathname == '/bookstore/homepage.html' || pathname == '/bookstore/new_listing.html') && localStorage.getItem('token') == null) {
		window.location.replace("index.html");
	}

	if(pathname == '/bookstore/index.html' && localStorage.getItem('token') !== null) {
		window.location.replace("homepage.html");
	}

});
