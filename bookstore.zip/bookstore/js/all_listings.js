$(window).on('load', function() {
	loadListings(); 
});

function loadListings() {
	 $.get("scripts/get_listings.php", function(data){
	 	var data = JSON.parse(data);
	 	var listingNumber = data.length;
	 	for(var i=0; i<listingNumber; i++) {
	 		createBookListing(i);
	 	}

	 	function createBookListing(i) {
	 		$("#book-listing-section").append("<div class=book-listing></div>")
	 		$(".book-listing:nth-child("+(i+1)+")").append("<div class='listing-book-name'><span class='listing-field'>Title: </span><span class='result'>"+data[i].bookName+ "</span></div>");
	 		$(".book-listing:nth-child("+(i+1)+")").append("<div class='listing-book-author'><span class='listing-field'>Author: </span><span class='result'>"+data[i].author+ "</div>");
	 		$(".book-listing:nth-child("+(i+1)+")").append("<div class='listing-book-description'><span class='listing-field'>Description: </span><span class='result'>"+data[i].bookDescription+ "</span></div>");
	 		$(".book-listing:nth-child("+(i+1)+")").append("<div class='listing-book-price'><span class='listing-field'>Price: </span><span class='result'>"+data[i].price+"</span></div>");
	 		$(".book-listing:nth-child("+(i+1)+")").append("<div class='listing-book-category'><span class='listing-field'>Category: </span><span class='result'>"+data[i].category+ "</span></div>");
	 		$(".book-listing:nth-child("+(i+1)+")").append("<div class='listing-book-ID'>"+data[i].ID+ "</div>");
	 		if(localStorage.getItem("token") !== null ) {
	 			$(".book-listing:nth-child("+(i+1)+")").append("<a href='#' id='editLink' data-toggle='modal' data-target='#editModal' class='pull-right editListing'>EDIT</div>");
	 			$(".book-listing:nth-child("+(i+1)+")").append("<a href='#' class='deleteListing'>DELETE</div>");
	 		} else {
	 			var sellerId = data[i].sellerId;
	 			getEmail(sellerId);
	 		}

	 		function getEmail(id) {
	 			var data = {
	 				sellerId: id,
	 			}; 
	 			$.post("scripts/seller_email.php", JSON.stringify(data), function(result){
	 				var answer = JSON.parse(result); 
	 				var name = answer[0].name;
	 				var email = answer[0].email;
	 				$(".book-listing:nth-child("+(i+1)+")").append("<a class='contact-seller' href='mailto:"+email+"'''>Contact Seller: "+name+"</a>");
	 			});
	 		}
	 	}
    });
}