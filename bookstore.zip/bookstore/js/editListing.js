$(document).ready(function() {
	$("#book-listing-section").on('click', '.book-listing a.editListing', editListing);
});

function editListing(e) {
	e.preventDefault();
	$('#bookName').attr('value',$(this).parent().find('.listing-book-name span.result')[0].innerHTML);
	$('#bookAuthor').attr('value', $(this).parent().find('.listing-book-author span.result')[0].innerHTML);
	document.getElementById('bookDescription').value = $(this).parent().find('.listing-book-description span.result')[0].innerHTML;
	$('#bookPrice').attr('value', $(this).parent().find('.listing-book-price span.result')[0].innerHTML);
	$('#bookCategory').attr('value', $(this).parent().find('.listing-book-category span.result')[0].innerHTML);
	var bookID = $(this).siblings('.listing-book-ID')[0].innerHTML;

	$('#edit-submit').click(function(e) {
		e.preventDefault();
		var data = {
			bookName : $('#bookName').val(),
			author : $('#bookAuthor').val(),
			description : $('#bookDescription').val(),
			price : $('#bookPrice').val(),
			category : $('#bookCategory').val(),
			id : bookID
		} 

		if (data.bookName.length == 0 || data.author.length == 0 || data.description.length == 0 || data.price.length == 0 || data.category.length == 0) {
			$('#editStatus').html('please make sure all fields are filled');
			$('#editStatus').addClass('error');
		} else {
			$.post("scripts/update_listing.php", JSON.stringify(data), function(result){
				if (result == 'successful') {
					$('#editStatus').html('edit was successful');
					$('#editStatus').addClass('success');
				} else {
					$('#editStatus').html('something went wrong, please try again');
					$('#editStatus').addClass('error');
				}
			});
		}
	});
}

