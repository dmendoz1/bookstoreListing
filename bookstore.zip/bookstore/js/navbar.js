function switchImages( newImagePath ) {
    var logo = $("#logo");
    logo.fadeOut(100, function() {
        logo.attr( "src", newImagePath );
        logo.fadeIn(100);
    } );
}

$(document).ready( function() {
    var mainHeader = $( "#main-header" ),
        defaultLogo = "images/big-logo.png",
        smallLogo = "images/small-logo.png";

    $(window).scroll( function() {
        if ($(window).scrollTop() > 100) {
            if (!mainHeader.hasClass("shrink")) {
                mainHeader.addClass( "shrink" );
                switchImages( smallLogo );
            }
        } else {
            if(mainHeader.hasClass( "shrink") ) {
                mainHeader.removeClass( "shrink" );
                switchImages( defaultLogo );
            }
        }
    } );
});