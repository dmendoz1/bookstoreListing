function NewBook(name, category, price, sellerId, author, description) {
	this.name = name;
	this.category = category;
	this.price = price;
	this.sellerId = sellerId;
	this.author = author;
	this.description = description;
}

NewBook.prototype.insertBook = function() {
	data = {
		name : this.name,
		category : this.category,
		price : this.price,
		sellerId : this.sellerId,
		author: this.author,
		description: this.description
	}

	if(data.name == '' || data.category == '' || data.price == '' || data.sellerId == '' || data.author == '' || data.description == '' ) {
		$('#new-listing-status').html('please fill all fields');
		$('#new-listing-status').addClass('error');
	} else {
		$.post("scripts/new_listing.php", JSON.stringify(data), function(result){
	        if(result == "successful") {
	        	$('#new-listing-status').html('Book was successfully added!');
	        	$('#new-listing-status').addClass('success');
	        } else {
	        	alert('something went wrong, please try again');
	        }
	    });
	}
}

$(document).ready(function() {
	$('#new-listing').click(function(e) {
		e.preventDefault();
		var bookName = $('#bookName').val();
		var bookCategory = $('#bookCategory').val();
		var bookPrice = $('#bookPrice').val();
		var bookSellerId = localStorage.getItem("userId");
		var bookDescription = $('#bookDescription').val();
		var bookAuthor = $('#bookAuthor').val();
		var newListing = new NewBook(bookName, bookCategory, bookPrice, bookSellerId, bookAuthor, bookDescription);
		newListing.insertBook();
	});
});