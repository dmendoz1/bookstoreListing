$(document).ready(function() {
	$("#book-listing-section").on('click', '.book-listing a.deleteListing', removeListing);
});

function removeListing(e) {
	e.preventDefault();
	var listingId = $(this).parent('.book-listing').children('.listing-book-ID')[0].innerText;
	var data = {
		id : listingId
	};
	$('#listingDeletePopup').fadeIn();
	$('#dontdelete-btn').click(function(){
		$('#listingDeletePopup').fadeOut();
	})
	$("#delete-btn").click(function() {
		$.post("scripts/delete_listing.php", JSON.stringify(data), function(result){
			if (result == 'successful') {
				$('#listingtUpdatePopup').fadeIn();
				$('#updateContact-close').click(function() {
					window.location.replace("homepage.html");
				})
			} else {
				alert('Sorry, something went wrong.  Please try again.');
			}
		});
	});
	$("#dontdelete-btn").click(function() {
		$('#contactDeletePopup').fadeOut();
	});
}